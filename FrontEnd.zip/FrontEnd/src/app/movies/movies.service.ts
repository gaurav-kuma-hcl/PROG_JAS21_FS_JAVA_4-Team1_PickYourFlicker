import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Movies } from './movies';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class MoviesService {
  movies: Movies[];
  
  constructor(private _httpClient: HttpClient) {
     

   }
  getAllmovies(): Observable<Movies[]>{
    console.log("getAllmovies");
    let url ="http://localhost:9090/moviesdetails";
    return this._httpClient.get<Movies[]>(url).pipe( map (response => response));
   
  
  }
}