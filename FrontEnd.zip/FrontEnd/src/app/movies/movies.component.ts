import { Component, OnInit } from '@angular/core';
import { Movies } from './movies';
import { MoviesService } from './movies.service';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})   
export class MoviesComponent {
  
  movie: Movies[] = [];
  constructor(private service: MoviesService) {
    this.service.getAllmovies().subscribe(data => {
      this.movie = data;
    });
  }
  
  ngOnInit() {
  }

}