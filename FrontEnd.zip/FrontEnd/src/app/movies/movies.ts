export class Movies {
    /*public id: number;
    public moviename: string;
    public movieslot: string;
    public movieschedule: string;
    public moviecost: number;*/
    constructor(public id: number,public name: string,public slot: string,public schedule: string,public cost: number)
    {
        
    }
      
}