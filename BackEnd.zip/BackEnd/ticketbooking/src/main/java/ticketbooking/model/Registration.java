package ticketbooking.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="registration")
public class Registration {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name="regseq")
	@Column(name="customerId")
    private int customerId;
	
	@Column(name="customerName")
    private String customerName;
	
	@Column(name="customerMobile")
    private String customerMobile;
	
	@Column(name="customerAddress")
    private String customerAddress;
	
	@Column(name="customerEmail")
    private String customerEmail;
	
	@Column(name="customerPassword")
    private String customerPassword;
    
	public Registration() 
	{
		super();
		
	}

	public Registration(int customerId, String customerName, String customerMobile, String customerAddress,
			String customerEmail, String customerPassword) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerMobile = customerMobile;
		this.customerAddress = customerAddress;
		this.customerEmail = customerEmail;
		this.customerPassword = customerPassword;
	}
	public Registration(String customerName, String customerMobile, String customerAddress,
			String customerEmail, String customerPassword) {
		super();
		this.customerName = customerName;
		this.customerMobile = customerMobile;
		this.customerAddress = customerAddress;
		this.customerEmail = customerEmail;
		this.customerPassword = customerPassword;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerMobile() {
		return customerMobile;
	}

	public void setCustomerMobile(String customerMobile) {
		this.customerMobile = customerMobile;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getCustomerPassword() {
		return customerPassword;
	}

	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}

	@Override
	public String toString() {
		return "Registration [customerId=" + customerId + ", customerName=" + customerName + ", customerMobile="
				+ customerMobile + ", customerAddress=" + customerAddress + ", customerEmail=" + customerEmail
				+ ", customerPassword=" + customerPassword + "]";
	}


    
	
	
	
}
