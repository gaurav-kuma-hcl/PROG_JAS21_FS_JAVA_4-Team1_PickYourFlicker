package ticketbooking.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="moviedetails")
public class Moviedetails {
    
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name="movseq")
	@Column(name="movieId")
	private int movieId;
	
	@Column(name="name")
	private String name;
	
	@Column(name="slot")
	private String slot;
	
	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSlot() {
		return slot;
	}

	public void setSlot(String slot) {
		this.slot = slot;
	}

	public String getSchedule() {
		return schedule;
	}

	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	@Column(name="schedule")
	private String schedule ;
	
	@Column(name="cost")
	private int cost;
	
	public Moviedetails() 
	{
		super();
	}

	public Moviedetails(int movieId, String name, String slot, String schedule, int cost) {
		super();
		this.movieId = movieId;
		this.name = name;
		this.slot = slot;
		this.schedule = schedule;
		this.cost = cost;
	}
	public Moviedetails(String name, String slot, String schedule, int cost) {
		super();
		this.name = name;
		this.slot = slot;
		this.schedule = schedule;
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "Moviedetails [movieId=" + movieId + ", name=" + name + ", slot=" + slot + ", schedule=" + schedule
				+ ", cost=" + cost + "]";
	}
	
	
}
